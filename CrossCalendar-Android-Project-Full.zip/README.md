Cross Calendar Android app source.
Features: monthly calendar, green X for Done, red X for Not done, clear mark, local saving.
Build using the GitHub Actions workflow in .github/workflows/build.yml.
