CROSS CALENDAR — BUILD THE INSTALLABLE APK

This project includes an automatic GitHub build workflow. It will create a debug APK for personal installation.

STEPS (a GitHub account is required):
1. On GitHub, create a new repository named CrossCalendar. Set it to Private if you prefer.
2. Upload all files and folders from this ZIP into the repository. Make sure the .github/workflows/build-apk.yml file is uploaded too. On mobile, GitHub's website may make folder uploads awkward; using a computer is easier.
3. Open the repository's Actions tab.
4. Select “Build Cross Calendar APK” and tap “Run workflow” (or wait for the first push build to finish).
5. Open the completed workflow run. Under Artifacts, download “CrossCalendar-APK”.
6. Extract the downloaded artifact ZIP. It contains app-debug.apk.
7. Transfer app-debug.apk to your Android phone and tap it to install. Android may ask you to allow installation from that source; only enable it for the file manager/browser you used, then turn it off again afterward.

The app stores marks locally on the device. It does not need an account or internet connection for calendar use. Keep a copy of the APK/project if you want to reinstall later; local marks may be lost if app data is cleared or the app is uninstalled.
