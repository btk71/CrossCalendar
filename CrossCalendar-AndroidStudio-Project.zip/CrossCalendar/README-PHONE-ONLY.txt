CROSS CALENDAR - PHONE-ONLY BUILD GUIDE

This project includes a GitHub Actions workflow to build the APK.

Important: uploading a ZIP file alone to GitHub will not build the app. The files must be placed in a GitHub repository with their folder structure preserved.

On an Android phone:
1. Download and extract CrossCalendar-AndroidStudio-Project.zip using your Files app.
2. In Chrome, open https://github.com and sign in.
3. Create a new public repository named CrossCalendar (or private if preferred).
4. Upload the extracted project files while preserving folders, including .github/workflows/android.yml. If GitHub's mobile upload interface cannot preserve folders, switch Chrome to Desktop site or use a GitHub-compatible file uploader.
5. Open the repository's Actions tab and select "Build Cross Calendar APK". Tap Run workflow if it has not started automatically.
6. Wait for the workflow to finish successfully.
7. Open the completed run, scroll to Artifacts, and download CrossCalendar-APK.
8. Extract the downloaded artifact and tap app-debug.apk. If Android blocks installation, allow your browser or Files app to install unknown apps, then retry. Only install the APK you built from your own repository.
